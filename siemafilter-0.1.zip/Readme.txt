This is a first beta version of the language filter mod.

It hides non english messages from the battle chat using an unsupervised language identification algorithm.


Installation:
As with all mods extract to you world of tanks folder